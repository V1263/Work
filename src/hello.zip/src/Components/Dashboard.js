import React from 'react'

export default function Dashboard () {
    return(
        <div>
            <h2>
                .Mahesh.
            </h2>
        </div>
    )
}


export  const Dashboard1 = ()=>{
    return(
        <div>
            <h2>
                .45465464.
            </h2>
        </div>
    )
}

export  const Dashboard3 = () => {
    return(
        <div>
            <h4>
                .Maqwertyu.
            </h4>
        </div>
    )
}
export  const Dashboard4 = () => {
    return(
        <div>
            <h4>
                .good morning.
            </h4>
        </div>
    )
}
export  const Dashboard5 = () => {
    return(
        <div>
            <h4>
                .bad morning.
            </h4>
        </div>
    )
}